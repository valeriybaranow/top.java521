package homeworks.Lambda;

public class Main {

    public static void main(String[] args) {
        Robot robot = new Robot(5, 5, Direction.LEFT);
        Robot.move(9,9, robot);
    }
}
