package homeworks.Lambda;

public enum TurnOptions {
    RIGHT, LEFT, NONE
}
