package homeworks.Stream;

public enum Gender {
    MALE, FEMALE
}
