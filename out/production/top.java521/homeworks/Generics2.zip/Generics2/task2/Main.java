package homeworks.Generics2.task2;


import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/*
    Шаблонные классы
        Задача 1.
        Создайте шаблонный класс Array, который представляет
        собой массив, позволяющий хранить объекты заданного типа.

        Необходимо реализовать:
         ■ заполнение массива с клавиатуры;
         ■ заполнение массива случайными числами;
         ■ отображение массива;
         ■ поиск максимального значения;
         ■ поиск минимального значения;
         ■ подсчет среднеарифметического значения;
         ■ сортировка массива по возрастанию;
         ■ сортировка массива по убыванию;
         ■ поиск значения в массиве, используя бинарный поиск;
         ■ замена значения в массиве на новое значение
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Array<Integer> array = new Array<>();
        System.out.print("Максимум массива: ");
        System.out.println(array.max());

        for (int i = 0; i < 5; i++) {
            System.out.print("Введите значение массива: ");
            array.add(scanner.nextInt());
        }
        System.out.println(array);
        // TODO: поиск и замена значения в массиве на новое значение не реализованы пока
//        System.out.print("Поиск по значению: ");
//        array.find(2);

        System.out.print("Введите количество рандомных значений для добавления в массив: ");
        int count = scanner.nextInt();
        Random rn = new Random();
        for (int i = 0; i < count; i++) {
            array.add(rn.nextInt((100 - 1) + 1));
        }
        System.out.println(array);

        System.out.print("Максимум массива: ");
        System.out.println(array.max());

        System.out.print("Минимум массива: ");
        System.out.println(array.min());

        System.out.print("Среднее арифметическое: ");
        System.out.println(array.average());

        System.out.print("Сортировка: ");
        array.sortAsc();
        System.out.println(array);

        System.out.print("Сортировка: ");
        array.sortDesc();
        System.out.println(array);
    }
}
